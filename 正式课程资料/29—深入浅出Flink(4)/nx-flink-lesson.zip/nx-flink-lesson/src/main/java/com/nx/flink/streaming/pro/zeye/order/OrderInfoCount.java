package com.nx.flink.streaming.pro.zeye.order;

import org.apache.flink.api.common.eventtime.*;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.AssignerWithPeriodicWatermarks;
import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction;
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.evictors.TimeEvictor;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.triggers.ContinuousEventTimeTrigger;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;

import javax.annotation.Nullable;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Iterator;

public class OrderInfoCount {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(1);

        env.readTextFile("D:\\soft\\work_space\\nx-flink-lesson\\src\\main\\data\\order_test")
                // env.readTextFile(Utils.ORDER_PATH)
                .map(new ParseOrder())
                .assignTimestampsAndWatermarks(
                        WatermarkStrategy
                                .forGenerator((ctx) -> new PeriodicWatermarkGenerator())
                                .withTimestampAssigner((ctx) -> new TimeStampExtractor())) //添加水位 //执行watermark
                .keyBy( order -> order.f0)
                .window(TumblingEventTimeWindows.of(Time.days(1), Time.hours(-8)))
                .trigger(ContinuousEventTimeTrigger.of(Time.seconds(10)))
                .evictor(TimeEvictor.of(Time.seconds(0),true))
                .process(new CountAmountProcess())
                .print();

        env.execute("OrderAmount");
    }


    public static class CountAmountProcess extends ProcessWindowFunction<Tuple3<String,String,Double>,Double, String, TimeWindow> {

        private ValueState<Double> amountState;

        @Override
        public void open(Configuration parameters) throws Exception {
            ValueStateDescriptor<Double> descriptor = new ValueStateDescriptor<Double>(
                    "amountState",
                    Double.class);
            amountState = getRuntimeContext().getState(descriptor);
        }

        @Override
        public void process(String key, Context context,
                            Iterable<Tuple3<String, String, Double>> iterable,
                            Collector<Double> out) throws Exception {
            Double count = amountState.value();
            if(count == null){
                count = 0.0;
            }
            Iterator<Tuple3<String, String, Double>> iterator = iterable.iterator();
            while(iterator.hasNext()){
                //对金额进行累加
                count += iterator.next().f2;

            }
            amountState.update(count);
            out.collect(count);
        }
    }

    private static class PeriodicWatermarkGenerator implements WatermarkGenerator<Tuple3<String,String,Double>>, Serializable {

        private long currentMaxEventTime = 0L;
        private long maxOutOfOrderness = 10000L; // 最大允许的乱序时间 10 秒

        @Override
        public void onEvent(
                Tuple3<String,String,Double> tuple, long eventTimestamp, WatermarkOutput output) {
            //指定时间字段
            SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            try {
                long date = TIME_FORMAT.parse(tuple.f1).getTime();
                currentMaxEventTime = Math.max(date, currentMaxEventTime);
            } catch (ParseException e) {
                e.printStackTrace();
            }

        }

        @Override
        public void onPeriodicEmit(WatermarkOutput output) {

            output.emitWatermark(new Watermark((currentMaxEventTime - maxOutOfOrderness)  ));
        }
    }

    private static class TimeStampExtractor implements TimestampAssigner<Tuple3<String,String,Double>> {
        @Override
        public long extractTimestamp(Tuple3<String,String,Double> tuple, long recordTimestamp) {
            //指定时间字段
            SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            try {
                long date = TIME_FORMAT.parse(tuple.f1).getTime();

                return date;
            } catch (ParseException e) {
                e.printStackTrace();
            }

            return 0;
        }
    }







    public static class ParseOrder implements MapFunction<String, Tuple3<String,String,Double>> {

        @Override
        public Tuple3<String, String, Double> map(String line) throws Exception {
            String[] fields = line.split("\t");
            String date = fields[6].trim();
            Double amount =Double.parseDouble( fields[1].trim());
            String day = date.split(" ")[0];
            return Tuple3.of(day,date,amount);
        }
    }

}
