package com.nx.flink.streaming.watermark.lesson06;



import org.apache.commons.lang3.time.FastDateFormat;
import org.apache.flink.api.common.eventtime.*;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction;
import org.apache.flink.streaming.api.windowing.assigners.SlidingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;

import java.io.Serializable;
import java.util.concurrent.TimeUnit;

/**
 * 需求：每隔5秒计算最近10秒的单词次数
 * 乱序
 */
public class WindowWordCountByWaterMark {
    public static void main(String[] args) throws  Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(1);
        DataStreamSource<String> dataStream = env.addSource(new TestSource());
       dataStream.flatMap(new FlatMapFunction<String, Tuple2<String, Long>>() {
            @Override
            public void flatMap(String s, Collector<Tuple2<String, Long>> collector) throws Exception {
                String[] fields = s.split(",");
                //拆分字段
                collector.collect(Tuple2.of(fields[0], Long.valueOf(fields[1])));
            }
            }).assignTimestampsAndWatermarks(
                         WatermarkStrategy
                       .forGenerator((ctx) -> new PeriodicWatermarkGenerator())
                       .withTimestampAssigner((ctx) -> new TimeStampExtractor())) //指定时间字段
               .keyBy(tuple -> tuple.f0) //指定分组的字段
               .window(SlidingEventTimeWindows.of(Time.seconds(10), Time.seconds(5))) //滑动窗口
               .process(new SumProcessFunction()) //计算结果
               .print();

        env.execute("WindowWordCountAndTime");

    }


    /**
     * 指定时间字段
     */
    private static class PeriodicWatermarkGenerator implements WatermarkGenerator<Tuple2<String, Long>>, Serializable {

        @Override
        public void onEvent(
                Tuple2<String, Long> event, long eventTimestamp, WatermarkOutput output) {
          //  System.out.println(eventTimestamp);
        }

        @Override
        public void onPeriodicEmit(WatermarkOutput output) {

            //指定可以延迟5s
            output.emitWatermark(new Watermark(System.currentTimeMillis() - 5000));
        }
    }

    /**
     * 指定eventTime字段
     */
    private static class TimeStampExtractor implements TimestampAssigner<Tuple2<String, Long>> {
        @Override
        public long extractTimestamp(Tuple2<String, Long> element, long recordTimestamp) {
            return element.f1;
        }
    }




    public static class TestSource implements
            SourceFunction<String> {
        FastDateFormat dateformat =  FastDateFormat.getInstance("HH:mm:ss");
        @Override
        public void run(SourceContext<String> cxt) throws Exception {
            String currTime = String.valueOf(System.currentTimeMillis());
            while(Integer.valueOf(currTime.substring(currTime.length() - 4)) > 100){
                currTime=String.valueOf(System.currentTimeMillis());
                continue;
            }
            System.out.println("当前时间："+dateformat.format(System.currentTimeMillis()));
            TimeUnit.SECONDS.sleep(13);
            //13
            String event="hadoop,"+System.currentTimeMillis();
            String event1=event;

            cxt.collect(event);

            TimeUnit.SECONDS.sleep(3);
            cxt.collect("hadoop,"+System.currentTimeMillis());

            TimeUnit.SECONDS.sleep(3);
            //19
            cxt.collect(event1);
            TimeUnit.SECONDS.sleep(3000);

        }

        @Override
        public void cancel() {

        }
    }

    /**
     * IN
     * OUT
     * KEY
     * W extends Window
     *
     */
    public static class  SumProcessFunction
            extends ProcessWindowFunction<Tuple2<String,Long>, Tuple2<String,Integer>, String, TimeWindow> {

        @Override
        public void process(String key, Context context,
                            Iterable<Tuple2<String, Long>> allElements,
                            Collector<Tuple2<String, Integer>> out) throws Exception {
            int count=0;
            for (Tuple2<String,Long> e:allElements){
               count++;
            }
            out.collect(Tuple2.of(key,count));
        }

    }
}
