/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.spark.deploy

import scala.collection.mutable.HashSet
import scala.concurrent.ExecutionContext
import scala.reflect.ClassTag
import scala.util.{Failure, Success}

import org.apache.log4j.Logger

import org.apache.spark.{SecurityManager, SparkConf}
import org.apache.spark.deploy.DeployMessages._
import org.apache.spark.deploy.master.{DriverState, Master}
import org.apache.spark.internal.Logging
import org.apache.spark.rpc.{RpcAddress, RpcEndpointRef, RpcEnv, ThreadSafeRpcEndpoint}
import org.apache.spark.util.{SparkExitCode, ThreadUtils, Utils}

/**
 * Proxy that relays messages to the driver.
 *
 * We currently don't support retry if submission fails. In HA mode, client will submit request to
 * all masters and see which one could handle it.
 */
private class ClientEndpoint(override val rpcEnv: RpcEnv, driverArgs: ClientArguments, masterEndpoints: Seq[RpcEndpointRef],
    conf: SparkConf) extends ThreadSafeRpcEndpoint with Logging {
    
    // A scheduled executor used to send messages at the specified time.
    private val forwardMessageThread = ThreadUtils.newDaemonSingleThreadScheduledExecutor("client-forward-message")
    
    // Used to provide the implicit parameter of `Future` methods.
    private val forwardMessageExecutionContext = ExecutionContext.fromExecutor(forwardMessageThread, t => t match {
        case ie: InterruptedException => // Exit normally
        case e: Throwable => logError(e.getMessage, e)
            System.exit(SparkExitCode.UNCAUGHT_EXCEPTION)
    })
    
    private val lostMasters = new HashSet[RpcAddress]
    private var activeMasterEndpoint: RpcEndpointRef = null
    
    private def getProperty(key: String, conf: SparkConf): Option[String] = {
        sys.props.get(key).orElse(conf.getOption(key))
    }
    
    /**
     * TODO_MA 马中华 https://blog.csdn.net/zhongqi2513
     *  注释： 到底是如何提交一个 job 到 master集群运行的呢？
     *  1、client 提交一个 请求到  master
     *  2、master 会选择一个 worker节点来运行　driver
     *  3、当 driver启动好了之后，会向　Master 进行注册
     *  4、当 master 接收到 driver的注册，并且处理成功之后，就会帮忙启动一堆 Executor
     */
    override def onStart(): Unit = {
        
        // TODO_MA 注释： 根据命令来执行
        driverArgs.cmd match {
            /**
             * TODO_MA 马中华 https://blog.csdn.net/zhongqi2513
             *  注释： 如果是启动
             *  当 clientApp 提交一个 job 到 Master　的时候：
             *  Master 执行解析之后，就要做两件事：
             *  1、启动一个 Driver
             *      给远程的某个 Worker 发送一个消息，在这个消息处理的内部，就会去启动 Driver
             *      具体的启动命令就是通过 java 代码执行一个 shell 命令。
             *      java org.apache.spark.deploy.worker.DriverWrapper
             *  2、启动一堆 Executor
             *      java ExecutorBackend
             */
            case "launch" => // TODO: We could add an env variable here and intercept it in `sc.addJar` that would
                // truncate filesystem paths similar to what YARN does. For now, we just require
                // people call `addJar` assuming the jar is in the same directory.
                val mainClass = "org.apache.spark.deploy.worker.DriverWrapper"
                
                val classPathConf = "spark.driver.extraClassPath"
                val classPathEntries = getProperty(classPathConf, conf).toSeq.flatMap { cp =>
                    cp.split(java.io.File.pathSeparator)
                }
                
                val libraryPathConf = "spark.driver.extraLibraryPath"
                val libraryPathEntries = getProperty(libraryPathConf, conf).toSeq.flatMap { cp =>
                    cp.split(java.io.File.pathSeparator)
                }
                
                val extraJavaOptsConf = "spark.driver.extraJavaOptions"
                val extraJavaOpts = getProperty(extraJavaOptsConf, conf).map(Utils.splitCommandString).getOrElse(Seq.empty)
                
                val sparkJavaOpts = Utils.sparkJavaOpts(conf)
                val javaOpts = sparkJavaOpts ++ extraJavaOpts
                
                // TODO_MA 注释： 封装 command， 第一个参数： mainClass = DriverWrapper
                val command = new Command(mainClass, Seq("{{WORKER_URL}}", "{{USER_JAR}}", driverArgs.mainClass) ++ driverArgs.driverOptions,
                    sys.env, classPathEntries, libraryPathEntries, javaOpts)
                
                // TODO_MA 注释： 注册 Driver 的时候会用到的 Driver 的启动信息等
                // TODO_MA 注释： 重要的是： command 包含了 Driver 的实现类是： DriverWrapper
                val driverDescription = new DriverDescription(driverArgs.jarUrl, driverArgs.memory, driverArgs.cores, driverArgs.supervise,
                    command)
                
                // TODO_MA 注释： 发送注册 Driver 的 RequestSubmitDriver 请求
                // TODO_MA 注释： 注册一个 Driver， 则Master会先找一个Worker启动Driver， 然后启动 Driver 之后初始化 SparkContext
                asyncSendToMasterAndForwardReply[SubmitDriverResponse](RequestSubmitDriver(driverDescription))
            
            /**
             * TODO_MA 马中华 https://blog.csdn.net/zhongqi2513
             *  注释： 如果是 kill
             */
            case "kill" => val driverId = driverArgs.driverId
                asyncSendToMasterAndForwardReply[KillDriverResponse](RequestKillDriver(driverId))
        }
    }
    
    /**
     * Send the message to master and forward the reply to self asynchronously.
     */
    private def asyncSendToMasterAndForwardReply[T: ClassTag](message: Any): Unit = {
        
        /**
         * TODO_MA 马中华 https://blog.csdn.net/zhongqi2513
         *  注释： 给所有 Master 都发送 RPC 请求用于提交 Application
         */
        for (masterEndpoint <- masterEndpoints) {
            
            // TODO_MA 注释： 发送请求
            masterEndpoint.ask[T](message).onComplete {
                case Success(v) => self.send(v)
                case Failure(e) => logWarning(s"Error sending messages to master $masterEndpoint", e)
            }(forwardMessageExecutionContext)
        }
    }
    
    /* Find out driver status then exit the JVM */ def pollAndReportStatus(driverId: String): Unit = {
        // Since ClientEndpoint is the only RpcEndpoint in the process, blocking the event loop thread
        // is fine.
        logInfo("... waiting before polling master for driver state")
        Thread.sleep(5000)
        logInfo("... polling master for driver state")
        
        // TODO_MA 注释： 发送 RequestDriverStatus 消息给 Master, 收到 DriverStatusResponse 消息
        val statusResponse = activeMasterEndpoint.askSync[DriverStatusResponse](RequestDriverStatus(driverId))
        
        if (statusResponse.found) {
            logInfo(s"State of $driverId is ${statusResponse.state.get}") // Worker node, if present
            (statusResponse.workerId, statusResponse.workerHostPort, statusResponse.state) match {
                case (Some(id), Some(hostPort), Some(DriverState.RUNNING)) => logInfo(s"Driver running on $hostPort ($id)")
                case _ =>
            } // Exception, if present
            statusResponse.exception match {
                case Some(e) => logError(s"Exception from cluster was: $e")
                    e.printStackTrace()
                    System.exit(-1)
                case _ => System.exit(0)
            }
        } else {
            logError(s"ERROR: Cluster master did not recognize $driverId")
            System.exit(-1)
        }
    }
    
    override def receive: PartialFunction[Any, Unit] = {
        
        /**
         * TODO_MA 马中华 https://blog.csdn.net/zhongqi2513
         *  注释：  处理 Driver 注册反馈
         */
        case SubmitDriverResponse(master, success, driverId, message) => logInfo(message)
            if (success) {
                activeMasterEndpoint = master
                pollAndReportStatus(driverId.get)
            } else if (!Utils.responseFromBackup(message)) {
                System.exit(-1)
            }
        case KillDriverResponse(master, driverId, success, message) => logInfo(message)
            if (success) {
                activeMasterEndpoint = master
                pollAndReportStatus(driverId)
            } else if (!Utils.responseFromBackup(message)) {
                System.exit(-1)
            }
    }
    
    override def onDisconnected(remoteAddress: RpcAddress): Unit = {
        if (!lostMasters.contains(remoteAddress)) {
            logError(s"Error connecting to master $remoteAddress.")
            lostMasters += remoteAddress // Note that this heuristic does not account for the fact that a Master can recover within
            // the lifetime of this client. Thus, once a Master is lost it is lost to us forever. This
            // is not currently a concern, however, because this client does not retry submissions.
            if (lostMasters.size >= masterEndpoints.size) {
                logError("No master is available, exiting.")
                System.exit(-1)
            }
        }
    }
    
    override def onNetworkError(cause: Throwable, remoteAddress: RpcAddress): Unit = {
        if (!lostMasters.contains(remoteAddress)) {
            logError(s"Error connecting to master ($remoteAddress).")
            logError(s"Cause was: $cause")
            lostMasters += remoteAddress
            if (lostMasters.size >= masterEndpoints.size) {
                logError("No master is available, exiting.")
                System.exit(-1)
            }
        }
    }
    
    override def onError(cause: Throwable): Unit = {
        logError(s"Error processing messages, exiting.")
        cause.printStackTrace()
        System.exit(-1)
    }
    
    override def onStop(): Unit = {
        forwardMessageThread.shutdownNow()
    }
}

/**
 * Executable utility for starting and terminating drivers inside of a standalone cluster.
 */
object Client {
    def main(args: Array[String]) {
        // scalastyle:off println
        if (!sys.props.contains("SPARK_SUBMIT")) {
            println("WARNING: This client is deprecated and will be removed in a future version of Spark")
            println("Use ./bin/spark-submit with \"--master spark://host:port\"")
        } // scalastyle:on println
        new ClientApp().start(args, new SparkConf())
    }
}

/**
 * TODO_MA 马中华 https://blog.csdn.net/zhongqi2513
 *  注释： 当提交给 Spark 集群的时候
 */
private[spark] class ClientApp extends SparkApplication {
    
    override def start(args: Array[String], conf: SparkConf): Unit = {
        
        // TODO_MA 注释： 解析参数
        val driverArgs = new ClientArguments(args)
        
        if (!conf.contains("spark.rpc.askTimeout")) {
            conf.set("spark.rpc.askTimeout", "10s")
        }
        Logger.getRootLogger.setLevel(driverArgs.logLevel)
        
        /**
         * TODO_MA 马中华 https://blog.csdn.net/zhongqi2513
         *  注释： 创建得到 NettyRpcEnv
         */
        val rpcEnv = RpcEnv.create("driverClient", Utils.localHostName(), 0, conf, new SecurityManager(conf))
        
        // TODO_MA 注释： 根据程序提交中指定的 master 地址获取对应的： EndpointRef 对象
        // TODO_MA 注释： 因为我们需要把 Job 提交到 master
        val masterEndpoints = driverArgs.masters.map(RpcAddress.fromSparkURL).map(rpcEnv.setupEndpointRef(_, Master.ENDPOINT_NAME))
        
        /**
         * TODO_MA 马中华 https://blog.csdn.net/zhongqi2513
         *  注释： 启动 ClientEndpoint
         *  负责给 Master 提交 Application
         *  -
         *  根据 Spark RPC 实现： 这句代码执行中，会去到两个地方：
         *  1、ClientEndpoint 的构造方法，其实里面并没有什么大动作！
         *  2、ClientEndpoint 的 onStart() 方法，这是重点
         */
        rpcEnv.setupEndpoint("client", new ClientEndpoint(rpcEnv, driverArgs, masterEndpoints, conf))
        
        rpcEnv.awaitTermination()
    }
}
