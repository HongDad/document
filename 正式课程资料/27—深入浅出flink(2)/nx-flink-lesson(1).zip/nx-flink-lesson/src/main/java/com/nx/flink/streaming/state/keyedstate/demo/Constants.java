package com.nx.flink.streaming.state.keyedstate.demo;

public class Constants {
    public static final String ORDER_INFO1_PATH="D:\\soft\\work_space\\nx-flink-lesson\\src\\main\\input\\OrderInfo1.txt";
    public static final String ORDER_INFO2_PATH="D:\\soft\\work_space\\nx-flink-lesson\\src\\main\\input\\OrderInfo2.txt";
}
