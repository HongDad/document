package com.mazh.hbase.core.phoenix;

import java.sql.*;

/**
 * Author：马中华 奈学教育 https://blog.csdn.net/zhongqi2513
 * DateTime：2020/9/15 13:51
 * Description：
 */
public class HBase_01_Phoenix_DriverAPI {

    public static void main(String[] args) throws Exception {
        // 请开始你的表演！

        // TODO_MA 注释：加载数据库驱动
        Class.forName("org.apache.phoenix.jdbc.PhoenixDriver");

        /********
         * TODO_MA 马中华 https://blog.csdn.net/zhongqi2513
         *   注释： 获取 Connection 链接对象
         *   1、指定数据库地址,格式为 jdbc:phoenix:Zookeeper 地址
         *   2、如果 HBase 采用 Standalone 模式或者伪集群模式搭建，则 HBase 默认使用内置的Zookeeper，默认端口为 2181
         */
        Connection connection = DriverManager.getConnection("jdbc:phoenix:bigdata02:2181");

        // TODO_MA 注释：获取 Statement 对象
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM us_population");

        // TODO_MA 注释：执行SQL语句
        ResultSet resultSet = statement.executeQuery();

        new com.fasterxml.jackson.databind.ObjectMapper();

        // TODO_MA 注释：解析结果
        while(resultSet.next()) {
            System.out.print(resultSet.getString("state") + "\t");
            System.out.print(resultSet.getString("city") + "\t");
            System.out.print(resultSet.getInt("population") + "\n");
        }

        // TODO_MA 注释：关闭连接
        statement.close();
        connection.close();

    }
}
