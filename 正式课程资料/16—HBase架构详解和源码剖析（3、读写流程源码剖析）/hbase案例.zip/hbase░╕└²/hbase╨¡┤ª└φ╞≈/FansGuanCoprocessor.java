package com.mazh.hbase.core.hbase.coprocessor;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Durability;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.coprocessor.BaseRegionObserver;
import org.apache.hadoop.hbase.coprocessor.ObserverContext;
import org.apache.hadoop.hbase.coprocessor.RegionCoprocessorEnvironment;
import org.apache.hadoop.hbase.regionserver.wal.WALEdit;

/**
 * 核心逻辑： 往fans表插入一条数据 :a--->b 那么就往guanzhu表插入一条数据：b---->a
 *
 */
public class FansGuanCoprocessor extends BaseRegionObserver {

	static Configuration config = HBaseConfiguration.create();
	static HTable table = null;
	static {
		config.set("hbase.zookeeper.quorum", "hadoop02:2181,hadoop03:2181,hadoop04:2181");
		try {
			table = new HTable(config, "guanzhu");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 在真正的put操作执行之前进行调用
	 */
	@Override
	public void prePut(ObserverContext<RegionCoprocessorEnvironment> e, Put put, WALEdit edit, Durability durability) throws IOException {

		RegionCoprocessorEnvironment ee = e.getEnvironment();
		HTable table2 = (HTable) ee.getTable(TableName.valueOf("xxx"));
		
		// 从put参数里面获取 a 和 b， rowkey， 和 value
		// 然后把a->b 转换成b->a然后插入进去guanzhu表

		// 取rowkey
		byte[] row = put.getRow();
		// 取存了插入数据的key-value的cell, 每个put参数里面只有一个
		Cell cell = put.get("f1".getBytes(), "from".getBytes()).get(0);
		
		
		
		// 初始化一个putIndex对象，并且指定rowkey
		byte[] value = cell.getValue();
		Put putIndex1 = new Put(value);
		
		
		Put putIndex = new Put(cell.getValueArray(), cell.getValueOffset(), cell.getValueLength());
		
		
		// 把put当中的celL当中的rowkey当做新的putIndex对象的value
		putIndex.addColumn("f1".getBytes(), "from".getBytes(), row);
		table.put(putIndex);
		table.close();
	}

	/**
	 * 在真正的put方法调用之后进行调用
	 */
	@Override
	public void postPut(ObserverContext<RegionCoprocessorEnvironment> e, Put put, WALEdit edit, Durability durability) throws IOException {
		// TODO Auto-generated method stub
		super.postPut(e, put, edit, durability);
	}
}
