package com.nx.hadoop.lesson05;



public class StopWatch {
    public static void main(String[] args) throws Exception {
        StopWatch stopwatch = new StopWatch();
        stopwatch.reset();
        stopwatch.start();
        Thread.sleep(2000);
        long elapse = stopwatch.getElapse();
        System.out.println("时间流逝了多少："+elapse);

        stopwatch.reStart();
        Thread.sleep(4000);
        elapse = stopwatch.getElapse();
        System.out.println("时间流逝了多少："+elapse);

    }
    //开始时间
    long start=0L;
    //统计时间流逝的时间
    long elapse=0L;

    /**
     * 重置时间
     * @return
     */
    public StopWatch reset(){
        long start=0L;
        long elapse=0L;
        return this;
    }

    /**
     * 记录开始时间
     * @return
     */
    public StopWatch start(){
        start=System.currentTimeMillis();
        return this;
    }

    /**
     * 重新计时
     * @return
     */
    public  StopWatch reStart(){
        return this.reset().start();
    }

    /**
     * 时间流逝了多久
     * @return
     */
    public long getElapse(){
        return System.currentTimeMillis() - start;
    }


}
