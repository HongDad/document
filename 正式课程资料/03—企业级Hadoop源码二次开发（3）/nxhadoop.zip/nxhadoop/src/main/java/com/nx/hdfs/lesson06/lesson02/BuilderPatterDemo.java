package com.nx.hdfs.lesson06.lesson02;


/**
 * 构建者模式
 */
public class BuilderPatterDemo {

    public static void main(String[] args) {
        //看起来就很好看了。
        Student student = new ConCreateStudent()
                .setField1("1")
                .setField2("2")
                .setField3("3")
                .build();


    }



    public static class Student{
        private String field1;
        private String field2;
        private String field3;

        public String getField1() {
            return field1;
        }

        public void setField1(String field1) {
            this.field1 = field1;
        }

        public String getField2() {
            return field2;
        }

        public void setField2(String field2) {
            this.field2 = field2;
        }

        public String getField3() {
            return field3;
        }

        public void setField3(String field3) {
            this.field3 = field3;
        }

        @Override
        public String toString() {
            return "Student{" +
                    "field1='" + field1 + '\'' +
                    ", field2='" + field2 + '\'' +
                    ", field3='" + field3 + '\'' +
                    '}';
        }
    }

    public interface Builder{
        Builder setField1(String field1);
        Builder setField2(String field2);
        Builder setField3(String field3);
        Student build();
    }

    public static class ConCreateStudent implements Builder{
         Student student=new Student();

        public Builder setField1(String field1) {
            System.out.println("非常复杂逻辑1");
            student.setField1(field1);
            return this;
        }

        public Builder setField2(String field2) {
            System.out.println("非常复杂逻辑2");
            student.setField2(field2);
            return this;
        }

        public Builder setField3(String field3) {
            System.out.println("非常复杂逻辑3");
            student.setField3(field3);
            return this;
        }

        public Student build() {
            return student;
        }
    }
}
