package com.nx.hdfs.lesson06.lesson05;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * HDFS目录树
 *
 * /主部门
 *      /子部门1
 *          /叶子部门1
 *          /叶子部门2
 *      /子部门2
 *          /叶子部门3
 *
 *
 *
 *   组合设计模式
 */
public class Department {


    public static void main(String[] args) {
        Department coreDep = new Department("主部门");
        Department dep1 = new Department("子部门1");
        Department dep2 = new Department("子部门2");
        Department leafDep1 = new Department("叶子部门1");
        Department leafDep2 = new Department("叶子部门2");
        Department leafDep3 = new Department("叶子部门3");

        coreDep.child.add(dep1);
        coreDep.child.add(dep2);
        dep1.child.add(leafDep1);
        dep1.child.add(leafDep2);
        dep2.child.add(leafDep3);

        coreDep.rename();






    }

    private  String name;//部门名
    private List<Department> child =new ArrayList<Department>();

    public Department(String name){
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Department> getChild() {
        return child;
    }

    public void setChild(List<Department> child) {
        this.child = child;
    }

    /**
     * 删除部门
     */
    public void remove() {
        if(this.child.size() > 0){
            for(Department sub:this.child){
                sub.remove();
            }
        }
        System.out.println("删除："+name);

    }


    /**
     *
     */
    public void rename() {
        if(this.child.size() > 0){
            for(Department sub:this.child){
                sub.rename();
            }
        }
        System.out.println("NX:"+name);

    }




}
