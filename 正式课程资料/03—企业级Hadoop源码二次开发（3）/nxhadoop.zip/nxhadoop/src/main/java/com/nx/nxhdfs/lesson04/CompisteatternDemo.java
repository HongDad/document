package com.nx.nxhdfs.lesson04;

import java.util.ArrayList;
import java.util.List;

/**
 * 文件目录树
 * 部门管理：
 *  主部门：
 *      子部门1
 *          叶子部门1
 *          叶子部门2
 *      子部门2
 *          叶子部门3
 */
public class CompisteatternDemo {
    public static void main(String[] args) {
        Department coreDept = new Department("主部门");
        Department subDept1 = new Department("子部门1");
        Department subDept2 = new Department("子部门2");
        Department leafDept1 = new Department("叶子部门1");
        Department leafDept2 = new Department("叶子部门2");
        Department leafDept3 = new Department("叶子部门3");

        coreDept.child.add(subDept1);
        coreDept.child.add(subDept2);
        subDept1.child.add(leafDept1);
        subDept1.child.add(leafDept2);
        subDept2.child.add(leafDept3);

        //删除
        coreDept.remove();
        coreDept.rename();

    }

    public static class Department{
        private String name;
        private List<Department> child=new ArrayList<Department>();

        public Department(String name){
            this.name = name;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public List<Department> getChild() {
            return child;
        }

        public void setChild(List<Department> child) {
            this.child = child;
        }


        public void remove(){
            if(this.child.size() >0){
                for (Department department:this.child){
                    department.remove();
                }
            }
            System.out.println("删除"+name);
        }

        public void rename(){
            if(this.child.size() > 0){
                for (Department department:this.child){
                    department.rename();
                }
            }
            System.out.println("NX"+name);
        }

    }

}
