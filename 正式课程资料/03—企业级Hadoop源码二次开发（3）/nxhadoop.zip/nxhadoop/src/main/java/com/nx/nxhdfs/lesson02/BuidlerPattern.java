package com.nx.nxhdfs.lesson02;

/**
 * 构建者模式
 */
public class BuidlerPattern {
    public static void main(String[] args) {
        //spark flink  函数式编程
        Student student = new ConCreateStudent()
                .setField1("f1")
                .setField2("f2")
                .setField3("f3")
                .build();

        System.out.println(student);
    }


    public static class Student{
        private String field1;
        private String field2;
        private String field3;

        public String getField1() {
            return field1;
        }

        public void setField1(String field1) {
            this.field1 = field1;
        }

        public String getField2() {
            return field2;
        }

        public void setField2(String field2) {
            this.field2 = field2;
        }

        public String getField3() {
            return field3;
        }

        public void setField3(String field3) {
            this.field3 = field3;
        }

        @Override
        public String toString() {
            return "Student{" +
                    "field1='" + field1 + '\'' +
                    ", field2='" + field2 + '\'' +
                    ", field3='" + field3 + '\'' +
                    '}';
        }
    }

    public interface Buidler{
        Buidler setField1(String field1);
        Buidler setField2(String field2);
        Buidler setField3(String field3);
        Student build();
    }

    public static class ConCreateStudent implements Buidler{
        Student student=new Student();

        public Buidler setField1(String field1) {
            System.out.println("执行了复杂逻辑1");
             student.setField1(field1);
             return this;
        }

        public Buidler setField2(String field2) {
            System.out.println("执行了复杂逻辑2");
            student.setField1(field2);
            return this;
        }

        public Buidler setField3(String field3) {
            System.out.println("执行了复杂逻辑3");
            student.setField1(field3);
            return this;
        }

        public Student build() {
            return student;
        }
    }
}
