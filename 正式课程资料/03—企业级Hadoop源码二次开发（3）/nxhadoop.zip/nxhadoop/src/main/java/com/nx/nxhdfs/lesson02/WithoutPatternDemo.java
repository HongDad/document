package com.nx.nxhdfs.lesson02;

public class WithoutPatternDemo {

    public static void main(String[] args) {
        Student student = new Student();

        if(true){//满足一定条件
            System.out.println("执行复杂的逻辑");
            student.setField1("1");
        }
        if(true){
            System.out.println("执行复杂的逻辑");
            student.setField2("2");
        }
        if(true){
            System.out.println("执行复杂的逻辑");
            student.setField3("3");
        }

        System.out.println(student);
    }

    public static class Student{
        private String field1;
        private String field2;
        private String field3;

        public String getField1() {
            return field1;
        }

        public void setField1(String field1) {
            this.field1 = field1;
        }

        public String getField2() {
            return field2;
        }

        public void setField2(String field2) {
            this.field2 = field2;
        }

        public String getField3() {
            return field3;
        }

        public void setField3(String field3) {
            this.field3 = field3;
        }

        @Override
        public String toString() {
            return "Student{" +
                    "field1='" + field1 + '\'' +
                    ", field2='" + field2 + '\'' +
                    ", field3='" + field3 + '\'' +
                    '}';
        }
    }
}
