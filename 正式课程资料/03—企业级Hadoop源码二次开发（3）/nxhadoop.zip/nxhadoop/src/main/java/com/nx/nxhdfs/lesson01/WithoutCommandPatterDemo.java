package com.nx.nxhdfs.lesson01;

public class WithoutCommandPatterDemo {
    public static void main(String[] args) {
        int style= 1;
        if(2 == style){
            Utils.read();
        }
        if(1 == style){
            Utils.write();
        }

    }

    public static class Utils{
        public static void read(){
            System.out.println("执行读的操作");
        }
        public static void write(){
            System.out.println("执行写的操作");
        }

    }
}
