package com.nx.hdfs.lesson07;

import java.util.HashMap;
import java.util.Map;

public class StopWatch {
    public static void main(String[] args)  throws  Exception{

        StopWatch stopWatch = new StopWatch();
        //开始计时
        stopWatch.start();
        Thread.sleep(2000);
        long elapse = stopWatch.getElapse();
        System.out.println("程序运行了多久"+elapse);
        //比如我们需要重新去统计另外一个地方的时间
        stopWatch.start();
        Thread.sleep(4000);
        long elapse1 = stopWatch.getElapse();
        System.out.println("程序运行了多久"+elapse1);


    }
    //开始时间
    long start=0;
    //时间流逝的时间
    long elapse = 0;

    /**
     * 开始计时
     * @return
     */
    public StopWatch start(){
        start = System.currentTimeMillis();
        return this;
    }

    /**
     * 重置时间： 一切重新计算
     * @return
     */
//    public StopWatch reset(){
//         start = 0;
//         elapse = 0;
//        return this;
//    }

    /**
     * 重新计时
     * @return
     */
//    public StopWatch restart(){
//        return this.reset().start();
//    }

    /**
     * 计算流逝的时间
     * @return
     */
    public long getElapse(){
        return System.currentTimeMillis() - start;
    }

}
