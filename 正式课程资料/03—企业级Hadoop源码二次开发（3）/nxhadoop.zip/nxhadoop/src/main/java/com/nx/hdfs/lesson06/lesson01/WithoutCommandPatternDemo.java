package com.nx.hdfs.lesson06.lesson01;

/**
 * 不用设计模式
 *
 * 命令模式（指令模式）
 *
 * Datanode -> 心跳 -> NameNode ->指令（命令） datanode
 *
 * DeleteBlockCommand
 * xxxCommand
 *
 */
public class WithoutCommandPatternDemo {
    public static void main(String[] args) {
        int style=1;
        if(style == 1){//符合某个条件
            //某个命令
            Utils.read();
        }else{
            //某个命令
            Utils.write();
        }

    }


    public static class Utils{
        public static void read(){
            System.out.println("读数据");
        }

        public static void write(){
            System.out.println("写数据");
        }
    }
}
