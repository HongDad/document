package com.nx.hadoop.lesson01;

/**
 * 定义了Hadoop RPC的协议
 * 其实就是一个接口
 */
public interface ClientProtocol {
    long versionID = 1245L;
    //创建目录
    void makeDir(String path);
}
