package com.nx.nxhdfs.lesson01;

/**
 * 指令模式
 */
public class CommandPatterDemo {

    public static void main(String[] args) {
        if( 1==1){
            Context context = new Context(new ReadCommand());
            context.execute();
        }else{
            Context context = new Context(new WriteCommand());
            context.execute();
        }


    }


    public interface Command{
        void execute();
    }

    public static class ReadCommand implements Command{

        public void execute() {
            System.out.println("执行读的指令");
        }
    }

    public static class WriteCommand implements Command{
        public void execute() {
            System.out.println("执行写的指令");
        }
    }

    public static class DeleteCommand implements  Command{

        public void execute() {
            System.out.println("执行删除指令");
        }
    }

    public static class Context{
        private Command command;
        public Context(Command command){
            this.command = command;
        }

        public void execute(){
            this.command.execute();
        }
    }




}
