/**
 * Serde and InputFormat support for connecting Hive to Accumulo tables.
 */
package org.apache.hadoop.hive.accumulo;