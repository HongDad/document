package com.nx.stream_bak1.ad;

import com.nx.stream_bak1.entity.AdClientLog;
import com.nx.stream_bak1.entity.AdLog;
import com.nx.stream_bak1.entity.AdServerLog;
import com.nx.stream_bak1.entity.schema.AdClientLogSchema;
import com.nx.stream_bak1.entity.schema.AdLogSchema;
import com.nx.stream_bak1.entity.schema.AdServerLogSchema;
import com.nx.stream_bak1.utils.Constants;
import com.nx.stream_bak1.utils.FlinkKafkaConsumerUtils;
import com.nx.stream_bak1.utils.FlinkKafkaProducerUtils;
import com.twitter.chill.protobuf.ProtobufSerializer;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer010;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer010;

import java.util.Properties;

public class StreamJoinJob {
    private static String KAFKA_SERVER_LOG = Constants.SERVER_LOG;
    private static String KAFKA_CLIENT_LOG = Constants.CLIENT_LOG;
    private static String KAFKA_AD_LOG = Constants.AD_LOG;
    private static String KAFKA_AD_LOG_REPORT = Constants.AD_LOG_REPORT;
    private static String BROKERS = Constants.BROKERS;

    public static void main(String[] args) throws Exception {
        String groupId = "flink-join-test2";
        // set up the streaming execution environment
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
//		final StreamExecutionEnvironment env = StreamExecutionEnvironment.createLocalEnvironment();
        env.enableCheckpointing(60000);
        env.setParallelism(2);
        env.getCheckpointConfig().setFailOnCheckpointingErrors(false);
        env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);
        env.getConfig().enableForceAvro();
        env.getConfig().registerTypeWithKryoSerializer(AdServerLog.class, ProtobufSerializer.class);
        env.getConfig().registerTypeWithKryoSerializer(AdLog.class, ProtobufSerializer.class);

        Properties properties = FlinkKafkaConsumerUtils.getConsumerProperties(BROKERS, KAFKA_SERVER_LOG, groupId);
        Properties properties2 = FlinkKafkaConsumerUtils.getConsumerProperties(BROKERS, KAFKA_CLIENT_LOG, groupId);
        // 添加数据源
        DataStreamSource<AdServerLog> adServerInputStream = env.addSource(
                new FlinkKafkaConsumer010<>(KAFKA_SERVER_LOG, new AdServerLogSchema(), properties));
        DataStreamSource<AdClientLog> adClientInputStream = env.addSource(
                new FlinkKafkaConsumer010<>(KAFKA_CLIENT_LOG, new AdClientLogSchema(), properties2));


        adServerInputStream.flatMap(new AdServerLogRichFlatMap()).name("WriteServerContext");

        DataStream<AdLog> adLogStream = adClientInputStream.flatMap(new AdClientLogRichFlatMap());
        // 添加sink
        Properties producerProperties = FlinkKafkaProducerUtils.getProducerProperties(BROKERS);
        FlinkKafkaProducer010<AdLog> adLogSink = new FlinkKafkaProducer010<AdLog>(KAFKA_AD_LOG, new AdLogSchema(), producerProperties);

        adLogStream.addSink(adLogSink).name("AdLogProcesser");

        // 同城会单独部署的ETL任务
        FlinkKafkaProducer010<String> adLogReportSink = new FlinkKafkaProducer010<String>(KAFKA_AD_LOG_REPORT, new SimpleStringSchema(), producerProperties);
        adLogStream.flatMap(new AdLogRichFlatMap()).addSink(adLogReportSink).name("AdLogReport");


        env.execute("Stream join job");
    }
}
