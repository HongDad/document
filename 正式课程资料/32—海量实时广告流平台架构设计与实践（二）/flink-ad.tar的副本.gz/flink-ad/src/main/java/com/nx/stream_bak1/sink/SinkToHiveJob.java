package com.nx.stream_bak1.sink;

import com.nx.stream_bak1.entity.AdClientLog;
import com.nx.stream_bak1.entity.AdLog;
import com.nx.stream_bak1.entity.AdServerLog;
import com.nx.stream_bak1.entity.schema.AdClientLogSchema;
import com.nx.stream_bak1.entity.schema.AdServerLogSchema;
import com.nx.stream_bak1.utils.Constants;
import com.nx.stream_bak1.utils.FlinkKafkaConsumerUtils;
import com.twitter.chill.protobuf.ProtobufSerializer;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.fs.bucketing.Bucketer;
import org.apache.flink.streaming.connectors.fs.bucketing.BucketingSink;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer010;

import java.util.Properties;

public class SinkToHiveJob {

    private static String KAFKA_SERVER_LOG = Constants.SERVER_LOG;
    private static String KAFKA_CLIENT_LOG = Constants.CLIENT_LOG;
    private static String KAFKA_AD_LOG = Constants.AD_LOG;
    private static String BROKERS = Constants.BROKERS;
    private static String partition = "'dt='yyyyMMdd/'hour'=HH";
    private static String HDFS_LOG_HOME = Constants.HDFS_LOG_HOME;

    public static void config(BucketingSink sink) {
        sink.setUseTruncate(false);
        sink.setBatchSize(1024 * 1024 * 256L); // 256M 一个文件
        sink.setBatchRolloverInterval(30 * 60 * 1000L);
        sink.setInactiveBucketThreshold(3 * 60 * 1000L);// 3分钟不写入就从 in-progress 转变为 pending
        sink.setInactiveBucketCheckInterval(30 * 1000L);// 30秒钟检查一次多久没有写入了，用于判断是否从 in-progress 转变为 pending
        sink.setInProgressSuffix(".in-progress");
        sink.setPendingSuffix(".pending");

    }

    public static void buildSink(DataStreamSource streamSource, String topic, Bucketer bucketer) {
        BucketingSink stringSink = new BucketingSink<>(HDFS_LOG_HOME + "json/" + topic);
        //通过这样的方式来实现数据按事件时间分区
        stringSink.setBucketer(bucketer);
        stringSink.setWriter(new ProtobufStringWriter<>());
        config(stringSink);
        streamSource.addSink(stringSink).name(topic + "-JsonSink");

    }


    public static void main(String[] args) throws Exception {

        String groupId = "flink-sink-task-test33";
        // set up the streaming execution environment
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
//        final StreamExecutionEnvironment env = StreamExecutionEnvironment.createLocalEnvironment();
        env.enableCheckpointing(60000);
        env.setParallelism(2);
        env.getCheckpointConfig().setFailOnCheckpointingErrors(false);
        env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);
        env.getConfig().enableForceAvro();
        env.getConfig().registerTypeWithKryoSerializer(AdServerLog.class, ProtobufSerializer.class);
        env.getConfig().registerTypeWithKryoSerializer(AdClientLog.class, ProtobufSerializer.class);
        env.getConfig().registerTypeWithKryoSerializer(AdLog.class, ProtobufSerializer.class);
        Properties properties = FlinkKafkaConsumerUtils.getConsumerProperties(BROKERS, KAFKA_SERVER_LOG, groupId);
        Properties properties2 = FlinkKafkaConsumerUtils.getConsumerProperties(BROKERS, KAFKA_CLIENT_LOG, groupId);
//        Properties properties3 = FlinkKafkaConsumerUtils.getConsumerProperties(BROKERS, KAFKA_AD_LOG, groupId);
        DataStreamSource<AdServerLog> adServerInputStream = env.addSource(
                new FlinkKafkaConsumer010<>(KAFKA_SERVER_LOG, new AdServerLogSchema(), properties));
        DataStreamSource<AdClientLog> adClientInputStream = env.addSource(
                new FlinkKafkaConsumer010<>(KAFKA_CLIENT_LOG, new AdClientLogSchema(), properties2));

        buildSink(adServerInputStream, KAFKA_SERVER_LOG, new AdServerEventTimeBucketer(partition));
        buildSink(adClientInputStream, KAFKA_CLIENT_LOG, new AdClientEventTimeBucketer(partition));

        env.execute("Stream sink job");

    }
}
