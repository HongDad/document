package com.nx.stream_bak1.ad;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nx.stream_bak1.entity.AdLog;
import com.nx.stream_bak1.entity.AdServerLog;
import com.nx.stream_bak1.entity.ProcessInfo;
import com.nx.stream_bak1.utils.*;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.windowing.RichWindowFunction;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.kafka.clients.producer.Producer;
import redis.clients.jedis.Jedis;

import java.util.Iterator;

public class AdLogRetryWindowFunction extends RichWindowFunction<AdLog, AdLog, String, TimeWindow> {
    String tableName = Constants.TABLE_NAME;
    HTable hTable;
    Jedis jedis;
    Producer producer;
    ObjectMapper objectMapper;

    @Override
    public void open(Configuration parameters) throws Exception {
        hTable = HBaseUtils.initHbaseClient(tableName);
        jedis = RedisUtils.initRedis();
        producer = KafkaProducerUtils.getProducer();
        objectMapper = new ObjectMapper();
        super.open(parameters);
    }


    @Override
    public void apply(String requestId, TimeWindow timeWindow, Iterable<AdLog> iterable, Collector<AdLog> collector) throws Exception {
        Iterator<AdLog> itr = iterable.iterator();
        while (itr.hasNext()) {
            AdLog adLog = itr.next();
            if (System.currentTimeMillis() - adLog.getProcessInfo().getProcessTimestamp() > 1000) {
                byte[] key = ETLUtils.generateBytesKey(adLog);
                AdServerLog context = ETLUtils.getContext(jedis, key);
                AdLog.Builder adLogBuilder = adLog.toBuilder();
                ProcessInfo.Builder processBuilder = adLog.getProcessInfo().toBuilder();
                processBuilder.setRetryCount(processBuilder.getRetryCount() + 1);
                processBuilder.setProcessTimestamp(System.currentTimeMillis());
                adLogBuilder.setProcessInfo(processBuilder.build());

                if (context == null && adLog.getProcessInfo().getRetryCount() < 5) {
                    ETLUtils.sendRetry(producer, adLogBuilder.build().toByteArray());
                } else {
                    ETLUtils.joinContext(adLogBuilder, context);
                    collector.collect(adLog);
                }
            }
        }
    }
}


