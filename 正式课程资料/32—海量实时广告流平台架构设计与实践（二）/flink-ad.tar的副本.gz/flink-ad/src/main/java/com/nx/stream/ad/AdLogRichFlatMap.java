package com.nx.stream.ad;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nx.stream.entity.AdClientLog;
import com.nx.stream.entity.AdLog;
import com.nx.stream.entity.AdServerLog;
import com.nx.stream.entity.dto.AdLogDTO;
import com.nx.stream.utils.*;
import org.apache.flink.api.common.functions.RichFlatMapFunction;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.util.Collector;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.kafka.clients.producer.Producer;
import redis.clients.jedis.Jedis;

public class AdLogRichFlatMap extends RichFlatMapFunction<AdLog, String> {
    ObjectMapper objectMapper;

    @Override
    public void open(Configuration parameters) throws Exception {
        objectMapper = new ObjectMapper();
        super.open(parameters);
    }

    @Override
    public void flatMap(AdLog adLog, Collector<String> collector) throws Exception {
        AdLogDTO adLogDTO = ETLUtils.buildAdLogDTO(adLog);
        collector.collect(objectMapper.writeValueAsString(adLogDTO));
    }
}


