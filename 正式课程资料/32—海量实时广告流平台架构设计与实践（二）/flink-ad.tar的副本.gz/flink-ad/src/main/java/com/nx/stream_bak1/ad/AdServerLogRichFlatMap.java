package com.nx.stream_bak1.ad;

import com.nx.stream_bak1.entity.AdServerLog;
import com.nx.stream_bak1.utils.Constants;
import com.nx.stream_bak1.utils.ETLUtils;
import com.nx.stream_bak1.utils.HBaseUtils;
import com.nx.stream_bak1.utils.RedisUtils;
import org.apache.flink.api.common.functions.RichFlatMapFunction;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.util.Collector;
import org.apache.hadoop.hbase.client.HTable;
import redis.clients.jedis.Jedis;

public class AdServerLogRichFlatMap extends RichFlatMapFunction<AdServerLog, String> {
    String tableName = Constants.TABLE_NAME;
    HTable hTable;
    Jedis jedis;

    int expire = 1 * 24 * 60 * 60;

    @Override
    public void open(Configuration parameters) throws Exception {
        hTable = HBaseUtils.initHbaseClient(tableName);
        jedis = RedisUtils.initRedis();
        super.open(parameters);
    }

    @Override
    public void flatMap(AdServerLog adServerLog, Collector<String> collector) throws Exception {
        byte[] key = ETLUtils.generateBytesKey(adServerLog);
        AdServerLog context = ETLUtils.generateContext(adServerLog);
        ETLUtils.writeRedis(jedis, key, context);
        ETLUtils.writeHbase(hTable, key, context);
    }

}

