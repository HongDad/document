package com.nx.flink.streaming.cep;


import com.nx.flink.streaming.pro.zeye.order.OrderAmount;
import com.nx.flink.streaming.pro.zeye.utils.Utils;
import org.apache.flink.api.common.eventtime.*;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.state.ListState;
import org.apache.flink.api.common.state.ListStateDescriptor;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.KeyedProcessFunction;
import org.apache.flink.util.Collector;

import java.io.Serializable;
import java.util.Iterator;

/**
 * 3秒之内连续失败2次，则进行风控
 */
public class LoginCheck {
    public static void main(String[] args) throws Exception {
        //步骤一：初始化程序入口
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(1);
        env.readTextFile(Utils.userLoginEvent)
                .map(new getLoginEvent())
                .keyBy(loginEvent -> loginEvent.userId)
                .process(new LoginWarning())
                .print();

        env.execute("LoginCheck");

    }


    public static class LoginWarning extends KeyedProcessFunction<Long,LoginEvent,Warning>{

        private ListState<LoginEvent> loginFailState;

        @Override
        public void open(Configuration parameters) throws Exception {
            // 注册状态
            ListStateDescriptor<LoginEvent> descriptor =
                    new ListStateDescriptor<LoginEvent>(
                            "loginFailState",  // 状态的名字
                            LoginEvent.class); // 状态存储的数据类型
            loginFailState = getRuntimeContext().getListState(descriptor);
        }

        @Override
        public void processElement(LoginEvent loginEvent,
                                   Context context,
                                   Collector<Warning> out) throws Exception {
            //来了一条登录失败的数据
            if (loginEvent.eventType.equalsIgnoreCase("fail")) {

                // 如果是失败，判断之前是否有登录失败事件
                Iterator<LoginEvent> iter = loginFailState.get().iterator();
                if (iter.hasNext()) {
                    // 如果已经有登录失败事件，就比较事件时间
                    //如果代码执行到这儿，就说明满足，已经是连续两次失败了。
                    LoginEvent firstFail = iter.next();

                    if (loginEvent.eventTime <
                            firstFail.eventTime + 3) {
                        // 如果两次间隔小于3秒，输出报警
                        out.collect(new Warning(loginEvent.userId, firstFail.eventTime, loginEvent.eventTime, "3秒内连续两次登录失败."));
                    }
                    // 更新最近一次的登录失败事件，保存在状态里
                    loginFailState.clear();
                    loginFailState.add(loginEvent);
                } else {
                    // 如果是第一次登录失败，直接添加到状态
                    loginFailState.add(loginEvent);
                }
            } else {
                // 如果是成功，清空状态
                loginFailState.clear();
            }

        }
    }


    private static class PeriodicWatermarkGenerator implements WatermarkGenerator<LoginEvent>, Serializable {

        private long currentMaxEventTime = 0L;
        private long maxOutOfOrderness = 10L; // 最大允许的乱序时间 10 秒

        @Override
        public void onEvent(
                LoginEvent loginEvent, long eventTimestamp, WatermarkOutput output) {
            long currentElementEventTime = loginEvent.eventTime;
            currentMaxEventTime = Math.max(currentMaxEventTime, currentElementEventTime);

        }

        @Override
        public void onPeriodicEmit(WatermarkOutput output) {
            output.emitWatermark(new Watermark((currentMaxEventTime - maxOutOfOrderness) * 1000  ));
        }
    }

    private static class TimeStampExtractor implements TimestampAssigner<LoginEvent> {
        @Override
        public long extractTimestamp(LoginEvent loginEvent, long recordTimestamp) {
           return loginEvent.eventTime * 1000;
        }
    }

    public static class getLoginEvent implements MapFunction<String,LoginEvent>{

        @Override
        public LoginEvent map(String line) throws Exception {
            String[] dataArray = line.split(",");

            return new LoginEvent(Long.parseLong(dataArray[0].trim()),
                    dataArray[1].trim(), dataArray[2].trim(),
                    Long.parseLong(dataArray[3].trim()) );
        }
    }



    public static class LoginEvent{
        private long userId;
        private String ip;
        private String eventType;
        private long eventTime;

        public LoginEvent(){

        }

        public LoginEvent(long userId, String ip,
                          String eventType, long eventTime) {
            this.userId = userId;
            this.ip = ip;
            this.eventType = eventType;
            this.eventTime = eventTime;
        }

        public long getUserId() {
            return userId;
        }

        public void setUserId(long userId) {
            this.userId = userId;
        }

        public String getIp() {
            return ip;
        }

        public void setIp(String ip) {
            this.ip = ip;
        }

        public String getEventType() {
            return eventType;
        }

        public void setEventType(String eventType) {
            this.eventType = eventType;
        }

        public long getEventTime() {
            return eventTime;
        }

        public void setEventTime(long eventTime) {
            this.eventTime = eventTime;
        }


    }

    public static class Warning{
        private long userId;
        private long firstFailTime;
        private long lastFailTime;
        private String warningMsg;

        public Warning(){

        }

        public Warning(long userId, long firstFailTime,
                       long lastFailTime, String warningMsg) {
            this.userId = userId;
            this.firstFailTime = firstFailTime;
            this.lastFailTime = lastFailTime;
            this.warningMsg = warningMsg;
        }

        public long getUserId() {
            return userId;
        }

        public void setUserId(long userId) {
            this.userId = userId;
        }

        public long getFirstFailTime() {
            return firstFailTime;
        }

        public void setFirstFailTime(long firstFailTime) {
            this.firstFailTime = firstFailTime;
        }

        public long getLastFailTime() {
            return lastFailTime;
        }

        public void setLastFailTime(long lastFailTime) {
            this.lastFailTime = lastFailTime;
        }

        public String getWarningMsg() {
            return warningMsg;
        }

        public void setWarningMsg(String warningMsg) {
            this.warningMsg = warningMsg;
        }

        @Override
        public String toString() {
            return "Warning{" +
                    "userId=" + userId +
                    ", firstFailTime=" + firstFailTime +
                    ", lastFailTime=" + lastFailTime +
                    ", warningMsg='" + warningMsg + '\'' +
                    '}';
        }
    }
}
