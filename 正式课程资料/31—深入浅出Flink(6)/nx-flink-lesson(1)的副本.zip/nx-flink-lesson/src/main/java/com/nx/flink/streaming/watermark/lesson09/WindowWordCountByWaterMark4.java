package com.nx.flink.streaming.watermark.lesson09;



import org.apache.commons.lang3.time.FastDateFormat;
import org.apache.flink.api.common.eventtime.*;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction;
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;
import org.apache.flink.util.OutputTag;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 需求：3秒一个窗口，把相同 key合并起来
 *
 * hadoop,1461756870000
 * hadoop,1461756883000
 * 迟到的数据
 * hadoop,1461756870000
 * hadoop,1461756871000
 * hadoop,1461756872000
 */
public class WindowWordCountByWaterMark4 {
    public static void main(String[] args) throws  Exception {
        //获取执行环境
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(1);
        //步骤一：设置时间类型
        //checkpoint

        DataStreamSource<String> dataStream = env.socketTextStream("192.168.123.102", 9999);

        OutputTag<Tuple2<String, Long>> outputTag = new OutputTag<Tuple2<String, Long>>("late-date"){};

        SingleOutputStreamOperator<String> result = dataStream.map(new MapFunction<String, Tuple2<String, Long>>() {
            @Override
            public Tuple2<String, Long> map(String line) throws Exception {
                String[] fields = line.split(",");
                return new Tuple2<>(fields[0], Long.valueOf(fields[1]));
            }
            //步骤二：获取数据里面的event Time
        }).assignTimestampsAndWatermarks(
                WatermarkStrategy
                        .forGenerator((ctx) -> new PeriodicWatermarkGenerator())
                        .withTimestampAssigner((ctx) -> new TimeStampExtractor())) //指定时间字段
                .keyBy(tuple -> tuple.f0)
                .window(TumblingEventTimeWindows.of(Time.seconds(3)))
                //.timeWindow(Time.seconds(3))
                //.allowedLateness(Time.seconds(2)) // 允许事件迟到 2 秒
                .sideOutputLateData(outputTag) //保留迟到太多的数据
                .process(new SumProcessWindowFunction());

        //结果打印
        result.print();


        /**
         *
         * 处理延迟的数据：
         * 侧输出流
         */
        result.getSideOutput(outputTag).map(new MapFunction<Tuple2<String,Long>, String>() {
            @Override
            public String map(Tuple2<String, Long> stringLongTuple2) throws Exception {
                /**
                 * 这个地方，我这儿只是把打印出来，实际工作里面：
                 * 可以把存储到持久化的引擎里面：1）kafka topic  2) Mysql 3) redis
                 * 1. 如果迟到的数据确实多，我们得调试程序。
                 * 2. 如果迟到的数据确实不多，我们就可以忽略不计。
                 */
                return "迟到数据："+stringLongTuple2.toString();
            }
        }).print();

        env.execute("WindowWordCountByWaterMark2");
    }

    /**
     * IN, OUT, KEY, W
     * IN：输入的数据类型
     * OUT：输出的数据类型
     * Key：key的数据类型（在Flink里面，String用Tuple表示）
     * W：Window的数据类型
     */
    public static class SumProcessWindowFunction extends
            ProcessWindowFunction<Tuple2<String,Long>,String, String, TimeWindow> {
        FastDateFormat dateFormat = FastDateFormat.getInstance("HH:mm:ss");

        @Override
        public void process(String key, Context context,
                            Iterable<Tuple2<String, Long>> elements,
                            Collector<String> out) throws Exception {
            System.out.println("处理时间：" + dateFormat.format(context.currentProcessingTime()));
            System.out.println("window start time : " + dateFormat.format(context.window().getStart()));

            List<String> list = new ArrayList<>();
            for (Tuple2<String, Long> ele : elements) {
                list.add(ele.toString() + "|" + dateFormat.format(ele.f1));
            }
            out.collect(list.toString());
            System.out.println("window end time  : " + dateFormat.format(context.window().getEnd()));

        }
    }



    private static class PeriodicWatermarkGenerator implements WatermarkGenerator<Tuple2<String, Long>>, Serializable {

        FastDateFormat dateFormat = FastDateFormat.getInstance("HH:mm:ss");

        private long currentMaxEventTime = 0L;
        private long maxOutOfOrderness = 10000; // 最大允许的乱序时间 10 秒

        @Override
        public void onEvent(
                Tuple2<String, Long> event, long eventTimestamp, WatermarkOutput output) {
            long currentElementEventTime = event.f1;
            currentMaxEventTime = Math.max(currentMaxEventTime, currentElementEventTime);
            System.out.println("event = " + event
                    + "|" + dateFormat.format(event.f1) // Event Time
                    + "|" + dateFormat.format(currentMaxEventTime)  // Max Event Time
                    + "|" + dateFormat.format(currentMaxEventTime - maxOutOfOrderness)); // Current Watermark
        }

        @Override
        public void onPeriodicEmit(WatermarkOutput output) {

            output.emitWatermark(new Watermark(currentMaxEventTime - maxOutOfOrderness ));
        }
    }

    private static class TimeStampExtractor implements TimestampAssigner<Tuple2<String, Long>> {
        @Override
        public long extractTimestamp(Tuple2<String, Long> element, long recordTimestamp) {
            return element.f1;
        }
    }
}
