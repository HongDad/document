package com.nx.flink.streaming.pro.zeye.utils;

public class Utils {

                                              //D:\soft\work_space\nx-flink-lesson\src\main\data\data1.csv

    public static final String APACHE_LOG_PAH="D:\\soft\\work_space\\nx-flink-lesson\\src\\main\\data\\data2.log";
    public static final String USER_BEHAVIOR_PATH="D:\\soft\\work_space\\nx-flink-lesson\\src\\main\\data\\data1.csv";
    public static final String ORDER_PATH = "D:\\soft\\work_space\\nx-flink-lesson\\src\\main\\data\\order_info.txt";

    public static final String CLICK_LOG_PATH="D:\\soft\\work_space\\nx-flink-lesson\\src\\main\\data\\data3.csv";

    //用户登录日志路径
    public static final String userLoginEvent = "D:\\soft\\work_space\\nx-flink-lesson\\src\\main\\data\\data4.csv";

    public static final String sensorInfoPath="D:\\soft\\work_space\\nx-flink\\src\\data\\data5.log";

}
