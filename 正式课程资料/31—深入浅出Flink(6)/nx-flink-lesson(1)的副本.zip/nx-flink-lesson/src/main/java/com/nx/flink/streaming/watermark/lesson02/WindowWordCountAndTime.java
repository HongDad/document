package com.nx.flink.streaming.watermark.lesson02;


import org.apache.commons.lang3.time.FastDateFormat;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.java.tuple.Tuple;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction;
import org.apache.flink.streaming.api.windowing.assigners.SlidingProcessingTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;

/**
 * 需求：每隔5秒计算最近10秒的单词次数
 *
 *
 * 窗口开始时间：20:17:03
 * 窗口结束时间：20:17:13
 *
 *窗口开始时间：20:17:08
 *窗口结束时间：20:17:18
 *
 */
public class WindowWordCountAndTime {
    public static void main(String[] args) throws  Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        DataStreamSource<String> dataStream = env.socketTextStream("192.168.123.102", 9999);
        dataStream.flatMap(new FlatMapFunction<String, Tuple2<String,Integer>>() {
            @Override
            public void flatMap(String line,
                                Collector<Tuple2<String, Integer>> out) throws Exception {
                String[] fields = line.split(",");
                for (String word:fields){
                    out.collect(Tuple2.of(word,1));
                }
            }
        })
                .keyBy(tuple -> tuple.f0)
               // .timeWindow(Time.seconds(10), Time.seconds(5))
                .window(SlidingProcessingTimeWindows.of(Time.seconds(10), Time.seconds(5)))
                .process(new SumProcessFunction())
                .print().setParallelism(1);
        //porcess foreach

        env.execute("WindowWordCountAndTime");

    }

    /**
     * IN
     * OUT
     * KEY
     * W extends Window
     *
     */
    public static class  SumProcessFunction
            extends ProcessWindowFunction<Tuple2<String,Integer>,
            Tuple2<String,Integer>, String, TimeWindow> {
        FastDateFormat dataformat=FastDateFormat.getInstance("HH:mm:ss");
        @Override
        public void process(String key, Context context,
                            Iterable<Tuple2<String, Integer>> allElements,
                            Collector<Tuple2<String, Integer>> out) throws Exception {
            System.out.println("当前系统时间："+dataformat.format(System.currentTimeMillis()));
            System.out.println("窗口处理时间："+dataformat.format(context.currentProcessingTime()));

            System.out.println("窗口开始时间："+dataformat.format(context.window().getStart()));
            System.out.println("窗口结束时间："+dataformat.format(context.window().getEnd()));

            System.out.println("=====================================================");

            //实现了sum的效果
            int count=0;
            for (Tuple2<String,Integer> e:allElements){
                count++;
            }
            out.collect(Tuple2.of(key,count));
        }

    }
}
