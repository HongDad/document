package com.nx.flink.streaming.cep;

import com.nx.flink.streaming.pro.zeye.utils.Utils;
import org.apache.flink.api.common.eventtime.*;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.cep.CEP;
import org.apache.flink.cep.PatternStream;
import org.apache.flink.cep.functions.PatternProcessFunction;
import org.apache.flink.cep.pattern.Pattern;
import org.apache.flink.cep.pattern.conditions.SimpleCondition;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.util.Collector;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

public class SensorWithCEP {
    public static void main(String[] args) throws Exception{
        //初始化程序入口
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(1);

        //读取数据
        KeyedStream<SensorInfo, String> stream = env.readTextFile(Utils.sensorInfoPath)
                .map(new getSensorInfo()) //把数据解析成对象
                .assignTimestampsAndWatermarks( //涉及到时间
                        WatermarkStrategy
                                .forGenerator((ctx) -> new PeriodicWatermarkGenerator())
                                .withTimestampAssigner((ctx) -> new TimeStampExtractor())) //指定时间字段
                .keyBy(sensorInfo -> sensorInfo.address);



        //定义复杂事件（定义匹配规则）
        Pattern<SensorInfo, SensorInfo> pattern = Pattern.<SensorInfo>begin("start").where(new SimpleCondition<SensorInfo>() {
            @Override
            public boolean filter(SensorInfo sensorInfo) throws Exception {
                return sensorInfo.temperature >= 40;
            }
        }).next("second").where(new SimpleCondition<SensorInfo>() {
            @Override
            public boolean filter(SensorInfo sensorInfo) throws Exception {
                return sensorInfo.temperature >= 40;
            }
        }).next("three").where(new SimpleCondition<SensorInfo>() {
            @Override
            public boolean filter(SensorInfo sensorInfo) throws Exception {
                return sensorInfo.temperature >= 40;
            }
        }).within(Time.minutes(3));

        //从无界的流里面检测复杂事件
        PatternStream<SensorInfo> result = CEP.pattern(stream, pattern);

        //获取匹配成功的事件
        result.process(new PatternProcessFunction<SensorInfo, String>() {
            @Override
            public void processMatch(Map<String,
                                     List<SensorInfo>> map,
                                     Context context,
                                     Collector<String> out) throws Exception {
                SensorInfo start = map.get("start").iterator().next();
                SensorInfo second = map.get("second").iterator().next();
                SensorInfo three = map.get("three").iterator().next();
                out.collect("设备："+start.address +"连续三次的温度是："+start.temperature +","+second.temperature + ", "+three.temperature +"引起注意！");

            }
        }).print();

        env.execute("SensorWithCEP");


    }


    private static class PeriodicWatermarkGenerator implements WatermarkGenerator<SensorInfo>, Serializable {

        private long currentMaxEventTime = 0L;
        private long maxOutOfOrderness = 10000L; // 最大允许的乱序时间 10 秒

        @Override
        public void onEvent(
                SensorInfo sensorInfo, long eventTimestamp, WatermarkOutput output) {
            long currentElementEventTime = sensorInfo.timeStamp;
            currentMaxEventTime = Math.max(currentMaxEventTime, currentElementEventTime);

        }

        @Override
        public void onPeriodicEmit(WatermarkOutput output) {
            output.emitWatermark(new Watermark((currentMaxEventTime - maxOutOfOrderness) ));
        }
    }

    private static class TimeStampExtractor implements TimestampAssigner<SensorInfo> {
        @Override
        public long extractTimestamp(SensorInfo sensorInfo, long recordTimestamp) {
            return sensorInfo.timeStamp ;
        }
    }

    public static class getLoginEvent implements MapFunction<String, LoginCheckWithCEP.LoginEvent>{

        @Override
        public LoginCheckWithCEP.LoginEvent map(String line) throws Exception {
            String[] dataArray = line.split(",");

            return new LoginCheckWithCEP.LoginEvent(Long.parseLong(dataArray[0].trim()),
                    dataArray[1].trim(), dataArray[2].trim(),
                    Long.parseLong(dataArray[3].trim()) );
        }
    }




    public static class getSensorInfo implements MapFunction<String,SensorInfo>{

        @Override
        public SensorInfo map(String line) throws Exception {
            String[] dataArray = line.split(",");
            SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            long timeStamp = TIME_FORMAT.parse(dataArray[1].trim()).getTime();
            return new SensorInfo(dataArray[0].trim(),timeStamp,Double.parseDouble(dataArray[2]));
        }
    }


    /**
     * 面向对象
     */
    public static class SensorInfo{
        private String address;
        private long timeStamp;
        private double temperature;

        public SensorInfo(){

        }

        public SensorInfo(String address, long timeStamp, double temperature) {
            this.address = address;
            this.timeStamp = timeStamp;
            this.temperature = temperature;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public long getTimeStamp() {
            return timeStamp;
        }

        public void setTimeStamp(long timeStamp) {
            this.timeStamp = timeStamp;
        }

        public double getTemperature() {
            return temperature;
        }

        public void setTemperature(double temperature) {
            this.temperature = temperature;
        }
    }
}
