/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.spark.deploy.client

import java.util.concurrent._
import java.util.concurrent.{Future => JFuture, ScheduledFuture => JScheduledFuture}
import java.util.concurrent.atomic.{AtomicBoolean, AtomicReference}

import scala.concurrent.Future
import scala.util.{Failure, Success}
import scala.util.control.NonFatal

import org.apache.spark.SparkConf
import org.apache.spark.deploy.{ApplicationDescription, ExecutorState}
import org.apache.spark.deploy.DeployMessages._
import org.apache.spark.deploy.master.Master
import org.apache.spark.internal.Logging
import org.apache.spark.rpc._
import org.apache.spark.util.{RpcUtils, ThreadUtils}

/**
 * Interface allowing applications to speak with a Spark standalone cluster manager.
 *
 * Takes a master URL, an app description, and a listener for cluster events, and calls
 * back the listener when various events occur.
 *
 * @param masterUrls Each url should look like spark://host:port.
 */
private[spark] class StandaloneAppClient(rpcEnv: RpcEnv, masterUrls: Array[String], appDescription: ApplicationDescription,
    listener: StandaloneAppClientListener, conf: SparkConf) extends Logging {
    
    private val masterRpcAddresses = masterUrls.map(RpcAddress.fromSparkURL(_))
    
    private val REGISTRATION_TIMEOUT_SECONDS = 20
    private val REGISTRATION_RETRIES = 3
    
    private val endpoint = new AtomicReference[RpcEndpointRef]
    private val appId = new AtomicReference[String]
    private val registered = new AtomicBoolean(false)
    
    /**
     * TODO_MA 马中华 https://blog.csdn.net/zhongqi2513
     *   注释：RpcEndpoint 三个生命周期方法：
     *   1、onStart 对象实例化之后，马上执行一次
     *   2、receive 接受消息进行处理，正常的服务方法
     *   3、onStop 在对象销毁之前，执行一次
     */
    private class ClientEndpoint(override val rpcEnv: RpcEnv) extends ThreadSafeRpcEndpoint with Logging {
        
        private var master: Option[RpcEndpointRef] = None
        // To avoid calling listener.disconnected() multiple times
        private var alreadyDisconnected = false
        // To avoid calling listener.dead() multiple times
        private val alreadyDead = new AtomicBoolean(false)
        private val registerMasterFutures = new AtomicReference[Array[JFuture[_]]]
        private val registrationRetryTimer = new AtomicReference[JScheduledFuture[_]]
        
        // A thread pool for registering with masters. Because registering with a master is a blocking
        // action, this thread pool must be able to create "masterRpcAddresses.size" threads at the same
        // time so that we can register with all masters.
        private val registerMasterThreadPool = ThreadUtils.newDaemonCachedThreadPool("appclient-register-master-threadpool",
            masterRpcAddresses.length // Make sure we can register with all masters at the same time
        )
        
        // A scheduled executor for scheduling the registration actions
        private val registrationRetryThread = ThreadUtils.newDaemonSingleThreadScheduledExecutor("appclient-registration-retry-thread")
        
        /**
         * TODO_MA 马中华 https://blog.csdn.net/zhongqi2513
         *   注释： 在  ClientEndpoint 创建成功之后，会立即执行该方法，向 Master 注册
         */
        override def onStart(): Unit = {
            try {
                /**
                 * TODO_MA 马中华 https://blog.csdn.net/zhongqi2513
                 *   注释：clientEndPoint 向 Master 执行注册
                 */
                registerWithMaster(1)
            } catch {
                case e: Exception => logWarning("Failed to connect to master", e)
                    markDisconnected()
                    stop()
            }
        }
        
        /**
         *  Register with all masters asynchronously and returns an array `Future`s for cancellation.
         */
        private def tryRegisterAllMasters(): Array[JFuture[_]] = {
            
            /**
             * TODO_MA 马中华 https://blog.csdn.net/zhongqi2513
             *   注释： 循环一次，尝试向一个 Master 注册！
             *   for(x <- array[1,2,3,4]) yield x * 2 = array[2,4,6,8]
             *   array[1,2,3,4].map(x => x * 2) = array[2,4,6,8]
             *   masterRpcAddresses 有可能有多个： 如果是 HA Spark 集群
             */
            for (masterAddress <- masterRpcAddresses) yield {
                // TODO_MA 注释：提交一个任务
                registerMasterThreadPool.submit(new Runnable {
                    override def run(): Unit = try {
                        if (registered.get) {
                            return
                        }
                        logInfo("Connecting to master " + masterAddress.toSparkURL + "...")
                        
                        /**
                         * TODO_MA 马中华 https://blog.csdn.net/zhongqi2513
                         *   注释：创建了一个 Master 的 RPC 代理
                         *   获取到 Master 的 Ref 对象
                         */
                        val masterRef = rpcEnv.setupEndpointRef(masterAddress, Master.ENDPOINT_NAME)
                        
                        /**
                         * TODO_MA 马中华 https://blog.csdn.net/zhongqi2513
                         *   注释： 向 Master 发送注册消息：RegisterApplication
                         *   本身： Master 就是一个 RpcEndpoint，所以他会有 receive 方法会负责执行 注册的处理
                         */
                        masterRef.send(RegisterApplication(appDescription, self))
                    } catch {
                        case ie: InterruptedException => // Cancelled
                        case NonFatal(e) => logWarning(s"Failed to connect to master $masterAddress", e)
                    }
                })
            }
        }
        
        /**
         * Register with all masters asynchronously. It will call `registerWithMaster` every
         * REGISTRATION_TIMEOUT_SECONDS seconds until exceeding REGISTRATION_RETRIES times.
         * Once we connect to a master successfully, all scheduling work and Futures will be cancelled.
         *
         * nthRetry means this is the nth attempt to register with master.
         */
        private def registerWithMaster(nthRetry: Int) {
            
            /**
             * TODO_MA 马中华 https://blog.csdn.net/zhongqi2513
             *   注释： 尝试向所有的 Master 注册
             *   Spark HA 集群： 多个 Master
             */
            registerMasterFutures.set(tryRegisterAllMasters())
            
            /**
             * TODO_MA 马中华 https://blog.csdn.net/zhongqi2513
             *   注释： 启动一个线程池，通过定时重试的方式，来保证注册成功
             */
            registrationRetryTimer.set(registrationRetryThread.schedule(new Runnable {
                override def run(): Unit = {
                    
                    // TODO_MA 注释：如果注册成功
                    if (registered.get) {
                        registerMasterFutures.get.foreach(_.cancel(true))
                        registerMasterThreadPool.shutdownNow()
                        
                        // TODO_MA 注释：如果超过重试次数
                    } else if (nthRetry >= REGISTRATION_RETRIES) {
                        markDead("All masters are unresponsive! Giving up.")
                        
                        // TODO_MA 注释： 尝试再次注册，注册次数累加
                    } else {
                        registerMasterFutures.get.foreach(_.cancel(true))
                        registerWithMaster(nthRetry + 1)
                    }
                }
            }, REGISTRATION_TIMEOUT_SECONDS, TimeUnit.SECONDS))
        }
        
        /**
         * Send a message to the current master. If we have not yet registered successfully with any
         * master, the message will be dropped.
         */
        private def sendToMaster(message: Any): Unit = {
            master match {
                case Some(masterRef) => masterRef.send(message)
                case None => logWarning(s"Drop $message because has not yet connected to master")
            }
        }
        
        private def isPossibleMaster(remoteAddress: RpcAddress): Boolean = {
            masterRpcAddresses.contains(remoteAddress)
        }
        
        /**
         * TODO_MA 马中华 https://blog.csdn.net/zhongqi2513
         *   注释：
         */
        override def receive: PartialFunction[Any, Unit] = {
            
            /**
             * TODO_MA 马中华 https://blog.csdn.net/zhongqi2513
             *   注释：接收到注册成功的消息
             *   处理注册成功的消息，是有可能产生问题的：
             *   1、如果因为网络不稳定，出现接受到多次 RegisteredApplication 消息怎么办？
             *   2、如果因为 Master 刚好做了切换，导致接收到多次 RegisteredApplication 消息怎么办？
             */
            case RegisteredApplication(appId_, masterRef) => // FIXME How to handle the following cases?
                // 1. A master receives multiple registrations and sends back multiple RegisteredApplications due to an unstable network.
                // 2. Receive multiple RegisteredApplication from different masters because the master is changing.
                appId.set(appId_)
                registered.set(true)
                master = Some(masterRef)
                
                // TODO_MA 注释： 这个 listener 就是： StandaloneSchedulerBackend
                listener.connected(appId.get)
            case ApplicationRemoved(message) => markDead("Master removed our application: %s".format(message))
                stop()
            
            /**
             * TODO_MA 马中华 https://blog.csdn.net/zhongqi2513
             *  注释： 一个 Driver要申请启动的 Executor 启动成功了。
             */
            case ExecutorAdded(id: Int, workerId: String, hostPort: String, cores: Int, memory: Int) => val fullId = appId + "/" + id
                logInfo("Executor added: %s on %s (%s) with %d core(s)".format(fullId, workerId, hostPort, cores))
                listener.executorAdded(fullId, workerId, hostPort, cores, memory)
                
            case ExecutorUpdated(id, state, message, exitStatus, workerLost) => val fullId = appId + "/" + id
                val messageText = message.map(s => " (" + s + ")").getOrElse("")
                logInfo("Executor updated: %s is now %s%s".format(fullId, state, messageText))
                if (ExecutorState.isFinished(state)) {
                    listener.executorRemoved(fullId, message.getOrElse(""), exitStatus, workerLost)
                }
            case WorkerRemoved(id, host, message) => logInfo("Master removed worker %s: %s".format(id, message))
                listener.workerRemoved(id, host, message)
            case MasterChanged(masterRef, masterWebUiUrl) => logInfo("Master has changed, new master is at " + masterRef.address.toSparkURL)
                master = Some(masterRef)
                alreadyDisconnected = false
                masterRef.send(MasterChangeAcknowledged(appId.get))
        }
        
        override def receiveAndReply(context: RpcCallContext): PartialFunction[Any, Unit] = {
            case StopAppClient => markDead("Application has been stopped.")
                sendToMaster(UnregisterApplication(appId.get))
                context.reply(true)
                stop()
            case r: RequestExecutors => master match {
                case Some(m) => askAndReplyAsync(m, context, r)
                case None => logWarning("Attempted to request executors before registering with Master.")
                    context.reply(false)
            }
            case k: KillExecutors => master match {
                case Some(m) => askAndReplyAsync(m, context, k)
                case None => logWarning("Attempted to kill executors before registering with Master.")
                    context.reply(false)
            }
        }
        
        private def askAndReplyAsync[T](endpointRef: RpcEndpointRef, context: RpcCallContext, msg: T): Unit = {
            // Ask a message and create a thread to reply with the result.  Allow thread to be
            // interrupted during shutdown, otherwise context must be notified of NonFatal errors.
            endpointRef.ask[Boolean](msg).andThen { case Success(b) => context.reply(b)
            case Failure(ie: InterruptedException) => // Cancelled
            case Failure(NonFatal(t)) => context.sendFailure(t)
            }(ThreadUtils.sameThread)
        }
        
        override def onDisconnected(address: RpcAddress): Unit = {
            if (master.exists(_.address == address)) {
                logWarning(s"Connection to $address failed; waiting for master to reconnect...")
                markDisconnected()
            }
        }
        
        override def onNetworkError(cause: Throwable, address: RpcAddress): Unit = {
            if (isPossibleMaster(address)) {
                logWarning(s"Could not connect to $address: $cause")
            }
        }
        
        /**
         * Notify the listener that we disconnected, if we hadn't already done so before.
         */
        def markDisconnected() {
            if (!alreadyDisconnected) {
                listener.disconnected()
                alreadyDisconnected = true
            }
        }
        
        def markDead(reason: String) {
            if (!alreadyDead.get) {
                listener.dead(reason)
                alreadyDead.set(true)
            }
        }
        
        override def onStop(): Unit = {
            if (registrationRetryTimer.get != null) {
                registrationRetryTimer.get.cancel(true)
            }
            registrationRetryThread.shutdownNow()
            registerMasterFutures.get.foreach(_.cancel(true))
            registerMasterThreadPool.shutdownNow()
        }
        
    }
    
    def start() {
        
        /**
         * TODO_MA 马中华 https://blog.csdn.net/zhongqi2513
         *   注释： 创建一个 ClientEndpoint，在创建 ClientEndpoint 实例创建成功之后，会立即执行 onStart 方法。
         *   在 onStart 方法中，会立即执行： 向 Master 注册 Application
         */
        // Just launch an rpcEndpoint; it will call back into the listener.
        endpoint.set(rpcEnv.setupEndpoint("AppClient", new ClientEndpoint(rpcEnv)))
    }
    
    def stop() {
        if (endpoint.get != null) {
            try {
                val timeout = RpcUtils.askRpcTimeout(conf)
                timeout.awaitResult(endpoint.get.ask[Boolean](StopAppClient))
            } catch {
                case e: TimeoutException => logInfo("Stop request to Master timed out; it may already be shut down.")
            }
            endpoint.set(null)
        }
    }
    
    /**
     * Request executors from the Master by specifying the total number desired,
     * including existing pending and running executors.
     *
     * @return whether the request is acknowledged.
     */
    def requestTotalExecutors(requestedTotal: Int): Future[Boolean] = {
        if (endpoint.get != null && appId.get != null) {
            endpoint.get.ask[Boolean](RequestExecutors(appId.get, requestedTotal))
        } else {
            logWarning("Attempted to request executors before driver fully initialized.")
            Future.successful(false)
        }
    }
    
    /**
     * Kill the given list of executors through the Master.
     * @return whether the kill request is acknowledged.
     */
    def killExecutors(executorIds: Seq[String]): Future[Boolean] = {
        if (endpoint.get != null && appId.get != null) {
            endpoint.get.ask[Boolean](KillExecutors(appId.get, executorIds))
        } else {
            logWarning("Attempted to kill executors before driver fully initialized.")
            Future.successful(false)
        }
    }
    
}
