package lesson01;

import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaPairDStream;
import org.apache.spark.streaming.api.java.JavaReceiverInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import scala.Tuple2;

import java.util.Arrays;
import java.util.Iterator;

public class WordCountForJava {
    public static void main(String[] args) throws  Exception{
        //步骤一：初始化程序入口
        SparkConf conf = new SparkConf();
        conf.setMaster("local[2]");
        conf.setAppName("wordcount");
        //new SparkContext(conf)
        JavaStreamingContext ssc = new JavaStreamingContext(conf, Durations.seconds(2));
        //步骤二:获取数据
        JavaReceiverInputDStream<String> dataStream = ssc.socketTextStream("hadoop1", 8888);
        //步骤三：处理数据
        //hadoop,hadoop,hive,hive
        //hadoop
        //hadoop
        //hive
        //hive
        JavaDStream<String> wordDSteram = dataStream.flatMap(new FlatMapFunction<String, String>() {
            @Override
            public Iterator<String> call(String line) throws Exception {
                String[] fields = line.split(",");
                return Arrays.asList(fields).iterator();
            }
        });
        JavaPairDStream<String, Integer> wordAndOneDStream = wordDSteram.mapToPair(new PairFunction<String, String, Integer>() {
            @Override
            public Tuple2<String, Integer> call(String word) throws Exception {
                return new Tuple2<String, Integer>(word, 1);
            }
        });

        JavaPairDStream<String, Integer> result = wordAndOneDStream.reduceByKey(new Function2<Integer, Integer, Integer>() {
            @Override
            public Integer call(Integer v1, Integer v2) throws Exception {
                return v1 + v2;
            }
        });
        //步骤四:打印数据
        result.print();
        //步骤五:启动程序
        ssc.start();
        ssc.awaitTermination();
        ssc.stop();
    }
}
