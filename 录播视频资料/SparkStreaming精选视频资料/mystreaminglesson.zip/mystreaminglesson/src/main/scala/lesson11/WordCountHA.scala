package lesson11

import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.{Seconds, StreamingContext}


object WordCountHA {
  //设置为HDFS的目录。
  val checkpointDirectory="C:\\Users\\Administrator\\Desktop\\SparkStreaming精讲\\checkpointdata1";

  def functionToCreateContext(): StreamingContext = {
    Logger.getLogger("org").setLevel(Level.ERROR)
    val conf = new SparkConf()
    conf.setMaster("local[2]")
    conf.setAppName("WordCount")
    val ssc = new StreamingContext(conf,Seconds(2))

    ssc.checkpoint(checkpointDirectory)
    //接受数据，形成了一个DStream
    val dataStream: DStream[String] = ssc.socketTextStream("hadoop1",8888)
    val lineDSteram: DStream[String] = dataStream.flatMap(_.split(","))
    val wordAndOneDStream: DStream[(String, Int)] = lineDSteram.map((_,1))

    val result = wordAndOneDStream.updateStateByKey((values: Seq[Int], state: Option[Int]) => {
      val currentCount = values.sum
      val lastCount = state.getOrElse(0)
      //在scala编程里面，最后一行代码就是返回值。
      Some(currentCount + lastCount)
    })
    result.print()

    ssc
  }

  def main(args: Array[String]): Unit = {
    Logger.getLogger("org").setLevel(Level.ERROR)
    //如果之前有，那么根据checkpoint目录里面的元数据信息，恢复出来一个程序入口（driver）
    //如果代码是第一次运行，或者说之前没有checkpoint目录，那么新创建一个程序入口。
    val ssc = StreamingContext.getOrCreate(checkpointDirectory, functionToCreateContext _)
    ssc.start()
    ssc.awaitTermination()
    ssc.stop()
  }

}
