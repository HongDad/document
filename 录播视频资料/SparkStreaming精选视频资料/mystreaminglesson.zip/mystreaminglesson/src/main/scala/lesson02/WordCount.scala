package lesson02


import org.apache.log4j.{Level, Logger}

import org.apache.spark.SparkConf
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.{Seconds, StreamingContext}

/**
  * WordCount:
  *   统计每个单词出现了多少次
  *   以前可能针对的是离线的数据，现在不一样，我针对的是实时的数据
  *   实时的统计每个单词出现了多少次。
  *
  *  数据的输入
  *
  *  数据的处理
  *  数据的输出
  */
object WordCount {
  def main(args: Array[String]): Unit = {

    //设置了日志的级别
    Logger.getLogger("org").setLevel(Level.ERROR)

    /**
      * 步骤一：
      *   创建程序入口
      */
    val conf = new SparkConf()


    /**
      * 如果你的代码需要在本地运行，那么这儿就需要设置conf.setMaaster的参数
      * 并且设成为local模式。
      * 如果你想要把任务提交到集群上面，那么就需要在代码里面这个
      * 这个setmaster的代码给注释了。
      * 换句话说，我们saprk的程序，默认是运行在集群上的。
      * 但是如果你想要运行在本地，那么你就设置setMaster
      */
    //conf.setMaster("local[2]")
    conf.setAppName("WordCount")
   // val sc = new SparkContext(conf)
    val ssc = new StreamingContext(conf,Seconds(2))

    /**
      * 步骤二：
      *   获取数据源
      */
    val dataStream: DStream[String] = ssc.socketTextStream("hadoop1",8888)

    /**
      * 步骤三：
      *   对数据进行处理
      *   使用的是SparkStreaming提供的算子
      *   处理的依据：按照公司的业务
      */
     val lineDSteram: DStream[String] = dataStream.flatMap(_.split(","))
     val wordAndOneDStream: DStream[(String, Int)] = lineDSteram.map((_,1))
     val result: DStream[(String, Int)] = wordAndOneDStream.reduceByKey(_+_)

    /**
      * 步骤四：
      *   数据的输出：
      *     正常情况下，我们肯定是要把数据输出到持久化的系统，然后再页面展示数据。
      *     但是我们这儿，为了测试，我们简单一点，直接输出的时候 打印数据就可以了。
      */
    result.print()

    /**
      * 步骤五：
      *   启动SparkStremaing
      */
    ssc.start()
    ssc.awaitTermination()
    ssc.stop()
  }

}
