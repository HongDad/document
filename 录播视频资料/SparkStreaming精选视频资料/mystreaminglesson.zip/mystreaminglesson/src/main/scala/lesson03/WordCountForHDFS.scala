package lesson03

import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.{Seconds, StreamingContext}

object WordCountForHDFS {
  def main(args: Array[String]): Unit = {
    //设置了日志的级别
    Logger.getLogger("org").setLevel(Level.ERROR)
    val conf = new SparkConf()
    conf.setMaster("local[2]")
    conf.setAppName("WordCount")
    val ssc = new StreamingContext(conf,Seconds(2))
    val dataDStream = ssc.textFileStream("hdfs://kkb/testinput")
    val reuslt = dataDStream.flatMap(_.split(","))
      .map((_, 1))
      .reduceByKey(_ + _)
    reuslt.print()
    ssc.start()
    ssc.awaitTermination()
    ssc.stop()
  }

}
