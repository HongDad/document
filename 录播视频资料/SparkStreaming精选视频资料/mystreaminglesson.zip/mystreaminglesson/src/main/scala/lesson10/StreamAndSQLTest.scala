package lesson10

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.streaming.{Seconds, StreamingContext}

object StreamAndSQLTest {
  def main(args: Array[String]): Unit = {
    Logger.getLogger("org").setLevel(Level.ERROR)

    val sparkConf = new SparkConf().setAppName("NetworkWordCount").setMaster("local[2]")
    val sc = new SparkContext(sparkConf)
    val ssc = new StreamingContext(sc, Seconds(2))
    val lines = ssc.socketTextStream("hadoop1", 8888)
    val words = lines.flatMap(_.split(","))
    //获取到的就是一个一个的单词
    words.foreachRDD( rdd =>{
      val spark = SparkSession.builder().config(rdd.sparkContext.getConf).getOrCreate()
      import spark.implicits._
      //隐式转换
      val wordDataFrame = rdd.toDF("word")
      //注册了一个临时的视图
      wordDataFrame.createOrReplaceTempView("words")
      spark.sql("select word,count(*) as totalCount from words group by word ")
        .show()

    })

    ssc.start()
    ssc.awaitTermination()
    ssc.stop()
  }

}
