//package lesson15.wordcount
//
//
//import kafka.serializer.StringDecoder
//import lesson15.kafkaoffset.{KafkaManager, KaikebaListener}
//import org.apache.spark.SparkConf
//import org.apache.spark.streaming.{Seconds, StreamingContext}
//
//
//
//object WordCount {
//  def main(args: Array[String]): Unit = {
//    val conf = new SparkConf().setMaster("local[3]").setAppName("wordCount")
//    conf.set("spark.streaming.kafka.maxRatePerPartition", "5")
//    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer");
//    val ssc = new StreamingContext(conf,Seconds(10))
//
//    val brokers = "hadoop2:9092"
//    val topics = "mysparkstreaming"
//    val groupId = "mysparkstreaming_consumer" //注意，这个也就是我们的消费者的名字
//
//    val topicsSet = topics.split(",").toSet
//
//    val kafkaParams = Map[String, String](
//      "metadata.broker.list" -> brokers,
//      "group.id" -> groupId
//    )
//    //关键步骤一：设置监听器，帮我们完成偏移量的提交
//
//    /**
//      * 监听器的作用就是，我们每次运行完一个批次，就帮我们提交一次偏移量。
//      */
//    ssc.addStreamingListener(
//      new KaikebaListener(kafkaParams));
//
//    //关键步骤二： 创建对象，然后通过这个对象获取到上次的偏移量，然后获取到数据流
//    val km = new KafkaManager(kafkaParams)
//    val messages = km.createDirectStream[String, String, StringDecoder, StringDecoder](
//      ssc, kafkaParams, topicsSet)
//     //完成你的业务逻辑即可
//     messages
//       .map(_._2)
//         .foreachRDD( rdd =>{
//           rdd.foreach( line =>{
//             println(line)
//             println("-============================================")
//           })
//         })
//
//    ssc.start()
//    ssc.awaitTermination()
//    ssc.stop()
//  }
//
//}
//
