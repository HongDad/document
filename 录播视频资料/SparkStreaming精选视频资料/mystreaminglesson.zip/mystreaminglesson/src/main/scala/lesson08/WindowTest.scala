package lesson08

import org.apache.log4j.{Level, Logger}
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.{SparkConf, SparkContext}

object WindowTest {
  def main(args: Array[String]): Unit = {
    Logger.getLogger("org").setLevel(Level.ERROR)

    val sparkConf = new SparkConf().setAppName("NetworkWordCount").setMaster("local[2]")
    val sc = new SparkContext(sparkConf)
    val ssc = new StreamingContext(sc, Seconds(2))
    val lines = ssc.socketTextStream("hadoop1", 8888)
    val words = lines.flatMap(_.split(","))
    val wordsDStream = words.map(x => (x, 1))

    /**
      * reduceFunc: (V, V) => V,
      * windowDuration: Duration,
      * slideDuration: Duration 滑动窗口的单位
      * 每隔2秒计算一下，最近4秒的单词出现的次数。
      */
    val result = wordsDStream.reduceByKeyAndWindow( (x:Int,y:Int) => x+y,Seconds(4),Seconds(2))
    result.print()
    ssc.start()
    ssc.awaitTermination()
    ssc.stop()
  }

}
